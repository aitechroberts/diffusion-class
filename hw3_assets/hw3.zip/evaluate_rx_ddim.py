"""
RX-DDIM Benchmark Script

Two evaluation modes:
  --mode kid   Generate samples for a single (method, step_count) config,
               compute KID via torch-fidelity, print parseable result line.
               Designed to be called in parallel (one Modal container per config).

  --mode l2    Run full L2 error sweep across all step counts on a single GPU.
               Uses 8 samples with shared initial noise vs 1000-step ground truth.
               Writes l2_vs_nfe.csv.

Usage:
    # KID for one config (called by Modal worker)
    python evaluate_rx_ddim.py --mode kid \\
        --checkpoint ckpt.pt --method rx_ddim --num_steps 10 \\
        --num_samples 5000 --batch_size 32 \\
        --output_dir /data/benchmark/rx_ddim_10 \\
        --dataset_path /data/celeba_images

    # L2 sweep (called once)
    python evaluate_rx_ddim.py --mode l2 \\
        --checkpoint ckpt.pt --rx_step_counts 1,5,10,25,50 \\
        --num_samples_l2 8 --seed 42 \\
        --output_csv benchmark/l2_vs_nfe.csv
"""

import os
import sys
import csv
import argparse
import subprocess

import torch
from tqdm import tqdm


def load_model(checkpoint_path, device):
    """Load checkpoint, apply EMA, return method + image_shape."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

    from src.models import create_model_from_config
    from src.methods import DDPM
    from src.utils import EMA

    checkpoint = torch.load(checkpoint_path, map_location=device)
    config = checkpoint["config"]

    model = create_model_from_config(config).to(device)
    model.load_state_dict(checkpoint["model"])

    ema = EMA(model, decay=config["training"]["ema_decay"])
    ema.load_state_dict(checkpoint["ema"])
    ema.apply_shadow()

    method = DDPM.from_config(model, config, device)
    method.eval_mode()

    data_cfg = config["data"]
    image_shape = (data_cfg["channels"], data_cfg["image_size"], data_cfg["image_size"])
    return method, image_shape


def save_individual_images(samples, output_dir, start_idx=0):
    """Save batch of samples as individual PNG files."""
    from src.data import unnormalize, save_image

    samples = unnormalize(samples)
    for i in range(samples.shape[0]):
        path = os.path.join(output_dir, f"{start_idx + i:06d}.png")
        save_image(samples[i : i + 1], path, nrow=1)


# =========================================================================
# Mode: kid
# =========================================================================

def run_kid_mode(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    method, image_shape = load_model(args.checkpoint, device)

    os.makedirs(args.output_dir, exist_ok=True)

    print(f"Generating {args.num_samples} samples: method={args.method}, steps={args.num_steps}")
    remaining = args.num_samples
    sample_idx = 0

    with torch.no_grad():
        pbar = tqdm(total=args.num_samples, desc="Generating")
        while remaining > 0:
            bs = min(args.batch_size, remaining)
            if args.method == "rx_ddim":
                samples = method.rx_ddim_sample(
                    batch_size=bs, image_shape=image_shape,
                    num_steps=args.num_steps, k=args.k,
                )
            else:
                samples = method.ddim_sample(
                    batch_size=bs, image_shape=image_shape,
                    num_steps=args.num_steps,
                )
            save_individual_images(samples, args.output_dir, start_idx=sample_idx)
            sample_idx += bs
            remaining -= bs
            pbar.update(bs)
        pbar.close()

    print(f"Running torch-fidelity KID...")
    fidelity_cmd = [
        "fidelity",
        "--gpu", "0",
        "--batch-size", str(args.batch_size),
        "--kid",
        "--input1", args.output_dir,
        "--input2", args.dataset_path,
    ]
    result = subprocess.run(fidelity_cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"fidelity stderr: {result.stderr}", file=sys.stderr)
        result.check_returncode()

    kid_mean, kid_std = None, None
    for line in result.stdout.strip().splitlines():
        if "kernel_inception_distance_mean" in line:
            kid_mean = float(line.split(":")[-1].strip())
        elif "kernel_inception_distance_std" in line:
            kid_std = float(line.split(":")[-1].strip())

    if kid_mean is None:
        print(f"Could not parse KID from output:\n{result.stdout}", file=sys.stderr)
        sys.exit(1)

    nfe = args.num_steps
    result_line = f"{args.method},{args.num_steps},{nfe},{kid_mean},{kid_std}"
    print(f"RESULT:{result_line}")
    return result_line


# =========================================================================
# Mode: l2
# =========================================================================

def run_l2_mode(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    method, image_shape = load_model(args.checkpoint, device)

    rx_steps = [int(s) for s in args.rx_step_counts.split(",")]
    n_samples = args.num_samples_l2

    print(f"L2 benchmark: {n_samples} samples, rx_steps={rx_steps}")
    print(f"Ground truth: DDIM @ 1000 steps")

    with torch.no_grad():
        # Generate ground truth with fixed seed
        torch.manual_seed(args.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(args.seed)
        gt = method.ddim_sample(
            batch_size=n_samples, image_shape=image_shape, num_steps=1000,
        )
        gt_flat = gt.reshape(n_samples, -1)
        gt_norm = torch.norm(gt_flat, dim=1)

        rows = []
        for rx_n in rx_steps:
            ddim_n = 2 * rx_n

            # RX-DDIM at rx_n steps
            torch.manual_seed(args.seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed(args.seed)
            rx_out = method.rx_ddim_sample(
                batch_size=n_samples, image_shape=image_shape,
                num_steps=rx_n, k=args.k,
            )
            rx_flat = rx_out.reshape(n_samples, -1)
            rx_l2 = torch.norm(rx_flat - gt_flat, dim=1) / gt_norm
            rx_mse = torch.mean((rx_flat - gt_flat) ** 2, dim=1)
            rows.append((
                "rx_ddim", rx_n, rx_n,
                rx_l2.mean().item(), rx_l2.std().item(),
                rx_mse.mean().item(), rx_mse.std().item(),
            ))
            print(f"  rx_ddim  steps={rx_n:>3d}  L2={rx_l2.mean():.6f}")

            # DDIM at 2x steps
            torch.manual_seed(args.seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed(args.seed)
            ddim_out = method.ddim_sample(
                batch_size=n_samples, image_shape=image_shape,
                num_steps=ddim_n,
            )
            ddim_flat = ddim_out.reshape(n_samples, -1)
            ddim_l2 = torch.norm(ddim_flat - gt_flat, dim=1) / gt_norm
            ddim_mse = torch.mean((ddim_flat - gt_flat) ** 2, dim=1)
            rows.append((
                "ddim", ddim_n, ddim_n,
                ddim_l2.mean().item(), ddim_l2.std().item(),
                ddim_mse.mean().item(), ddim_mse.std().item(),
            ))
            print(f"  ddim     steps={ddim_n:>3d}  L2={ddim_l2.mean():.6f}")

    # Sort by nfe for cleaner output
    rows.sort(key=lambda r: (r[2], r[0]))

    os.makedirs(os.path.dirname(os.path.abspath(args.output_csv)), exist_ok=True)
    with open(args.output_csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["method", "num_steps", "nfe", "l2_mean", "l2_std", "mse_mean", "mse_std"])
        for row in rows:
            writer.writerow(row)

    print(f"\nL2 results written to {args.output_csv}")


# =========================================================================
# CLI
# =========================================================================

def main():
    parser = argparse.ArgumentParser(description="RX-DDIM benchmark evaluation")
    parser.add_argument("--mode", required=True, choices=["kid", "l2"],
                        help="Evaluation mode: kid (single config) or l2 (full sweep)")
    parser.add_argument("--checkpoint", required=True, help="Path to model checkpoint")
    parser.add_argument("--k", type=int, default=2, help="RX-DDIM extrapolation interval")

    # KID mode args
    parser.add_argument("--method", type=str, default="ddim", choices=["ddim", "rx_ddim"])
    parser.add_argument("--num_steps", type=int, default=10)
    parser.add_argument("--num_samples", type=int, default=5000)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--output_dir", type=str, default="benchmark/generated")
    parser.add_argument("--dataset_path", type=str, default="/data/celeba_images")

    # L2 mode args
    parser.add_argument("--rx_step_counts", type=str, default="1,5,10,25,50")
    parser.add_argument("--num_samples_l2", type=int, default=8)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_csv", type=str, default="benchmark/l2_vs_nfe.csv")

    args = parser.parse_args()

    if args.mode == "kid":
        run_kid_mode(args)
    elif args.mode == "l2":
        run_l2_mode(args)


if __name__ == "__main__":
    main()
